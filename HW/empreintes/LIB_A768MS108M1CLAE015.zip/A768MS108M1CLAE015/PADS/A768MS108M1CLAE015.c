*PADS-LIBRARY-SCH-DECALS-V9*

A768MS108M1CLAE015 32000 32000 100 10 100 10 4 4 0 2 24
TIMESTAMP 2018.01.18.07.51.54
"Default Font"
"Default Font"
350   250   0 24 100 10 "Default Font"
REF-DES
350   150   0 24 100 10 "Default Font"
PART-TYPE
250   -150  0 28 100 10 "Default Font"
*
250   -250  0 28 100 10 "Default Font"
*
OPEN   2 10 0 -1
220   100  
220   -100 
OPEN   2 10 0 -1
280   100  
280   -100 
OPEN   2 10 0 -1
200   0    
220   0    
OPEN   2 10 0 -1
280   0    
300   0    
T0     0     0 0 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T500   0     0 2 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0

*END*
